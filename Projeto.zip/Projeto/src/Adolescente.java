
public class Adolescente extends Pessoa {
	Pessoa crianca;
	String escola;
	
	public String come() {
		return "Rosnando";
	}

	public Adolescente(String nomeParametro, int idadeParametro, String escolaParametro) {
		super(nomeParametro, idadeParametro);
		this.escola = escolaParametro;
	}
	
	@Override
	public String toString() {
		String aux = "";
		aux += "Nome: " + nome + "\n";
		aux += "Idade: " + idade + "\n";
		aux += "Escola: " + escola + "\n";
		return aux;
	}
}
