
public class Crianca extends Pessoa {

	Pessoa crianca;
	String escola;
	
	public String come() {
		return "Comendo";
	}

	public Crianca(String nomeParametro, int idadeParametro, String escolaParametro) {
		super(nomeParametro, idadeParametro);
		this.escola = escolaParametro;
	}
	
	@Override
	public String toString() {
		String aux = "";
		aux += "Nome: " + nome + "\n";
		aux += "Idade: " + idade + "\n";
		aux += "Escola: " + escola + "\n";
		return aux;
	}
}
