
public abstract class Pessoa {
	String nome;
	int idade;

	public Pessoa(String nomeParametro, int idadeParametro) {
		this.nome = nomeParametro;
		this.idade = idadeParametro;
	}

	public String come() {
		return "Comendo";
	}

	@Override
	public String toString() {
		String aux = "";
		aux += "Nome: " + nome + "\n";
		aux += "Idade: " + idade + "\n";
		return aux;
	}

	public String getNome() {
		return nome;
	}

}
