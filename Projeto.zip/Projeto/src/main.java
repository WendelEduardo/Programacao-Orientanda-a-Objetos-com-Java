import java.util.ArrayList;

public class main {
	public static void main(String[] args) {

		ArrayList<Pessoa> pessoa = new ArrayList<Pessoa>();

		//Crianca raquel = new Crianca("a", 21, "nemesio");

		pessoa.add(new Adolescente("Raquel", 21, "Nemesio"));
		pessoa.add(new Crianca("Wendel", 13, "Nemesio"));
		
		for(int i=0; i<pessoa.size(); i++) {
			//System.out.println(pessoa.get(i));
			
			if(pessoa.get(i) instanceof Crianca) {
				System.out.println(pessoa.get(i) + " � crian�a");
				System.out.println(pessoa.get(i).come() + "\n");
			}else if(pessoa.get(i) instanceof Adolescente) {
				System.out.println(pessoa.get(i) + " � adolescente" );
				System.out.println(pessoa.get(i).come() + "\n");
			}
		}

		//System.out.println(raquel);

	}
}
